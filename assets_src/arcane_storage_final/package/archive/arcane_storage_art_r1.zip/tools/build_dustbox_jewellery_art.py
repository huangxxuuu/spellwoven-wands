"""Pack generated jewellery-case art into an anchored, two-sided lid animation.

No illustration is drawn here: masks split generated surfaces, geometry animates
the rigid lid, and generated content layers are composited behind the rim.
Original imagegen files stay unchanged. No mod runtime files are touched.
"""
from __future__ import annotations
import json
import math
from pathlib import Path
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageOps

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'assets_src/arcane_storage_final/dustbox'
SOURCE = DEST / 'originals'
SIZE = (1254, 1254)
CANVAS = (160, 160)
ANCHOR = (80, 148)
SCALE = 0.125
SOURCE_ANCHOR = (627, 1048)
LEVELS = ('empty', 'half', 'full')


def cleaned(im):
    """Remove only sub-visible alpha noise outside generated silhouettes."""
    im = im.convert('RGBA')
    a = np.array(im)
    a[a[:, :, 3] <= 8] = 0
    a[:, :, 3][a[:, :, 3] >= 250] = 255
    return Image.fromarray(a)


def polygon_mask(points):
    mask = Image.new('L', SIZE)
    ImageDraw.Draw(mask).polygon(points, fill=255)
    return mask


def part(im, mask):
    result = im.copy()
    result.putalpha(ImageChops.multiply(im.getchannel('A'), mask))
    return result


def hinged(surface, factor, shear=0):
    # Axis y = intercept + slope*x. It is stationary throughout each clip.
    slope, intercept = -0.085, 700.0
    # y' = k*y + (1-k)*(intercept+slope*x)
    # Optional x displacement is zero at the hinge and grows away from it.
    matrix = np.array([[1-shear*slope, shear, -shear*intercept],
                       [(1-factor)*slope, factor, (1-factor)*intercept],
                       [0, 0, 1]], dtype=float)
    inverse = np.linalg.inv(matrix)
    return surface.transform(SIZE, Image.Transform.AFFINE,
                             tuple(inverse[:2].reshape(-1)), Image.Resampling.BICUBIC)


def world(image):
    out = Image.new('RGBA', CANVAS)
    resized = image.resize((round(SIZE[0]*SCALE), round(SIZE[1]*SCALE)), Image.Resampling.LANCZOS)
    xy = (round(ANCHOR[0]-SOURCE_ANCHOR[0]*SCALE), round(ANCHOR[1]-SOURCE_ANCHOR[1]*SCALE))
    out.alpha_composite(resized, xy)
    return cleaned(out)


def icon(image):
    image = cleaned(image)
    bounds = image.getchannel('A').point(lambda a: 255 if a > 16 else 0).getbbox()
    item = ImageOps.contain(image.crop(bounds), (60, 60), Image.Resampling.LANCZOS)
    out = Image.new('RGBA', (64,64))
    out.alpha_composite(item, ((64-item.width)//2, (64-item.height)//2))
    return cleaned(out)


def preview_sprite(im, size=320, background=(190,184,170,255)):
    im = im.resize((size, size), Image.Resampling.NEAREST)
    bg = Image.new('RGBA', im.size, background)
    draw = ImageDraw.Draw(bg)
    # Review-only representation of the existing engine DynamicShadow.
    draw.ellipse((size*.15, size*.885, size*.85, size*.985), fill=(95,89,82,255))
    bg.alpha_composite(im)
    return bg.convert('RGB')


def main():
    for folder in ('parts', 'world', 'inventory', 'review'):
        (DEST/folder).mkdir(parents=True, exist_ok=True)
    empty = cleaned(Image.open(SOURCE/'open_empty.png'))
    outer = cleaned(Image.open(SOURCE/'closed.png'))
    # Follow the actual back-rim separation, including the clipped corners;
    # a straight split would leave a sliver of the open lid on the fixed body.
    body_mask = polygon_mask([(0,735),(228,697),(286,677),(430,664),
                              (705,641),(831,623),(875,622),(1254,595),
                              (1254,1254),(0,1254)])
    lid_mask = ImageChops.invert(body_mask)
    lid_inside = part(empty, lid_mask)
    body = part(empty, ImageChops.invert(lid_mask))
    # Cover the split line with original generated hinge artwork; no repainted seam.
    hinges_mask = polygon_mask([(326,650),(334,646),(412,639),(422,645),
                                (426,660),(422,678),(333,684),(326,677)])
    hinges_mask = ImageChops.lighter(hinges_mask, polygon_mask(
        [(718,616),(725,610),(802,607),(811,614),(813,631),(807,642),(725,648),(717,638)]))
    hinges = part(empty, hinges_mask)
    # The front thumb clasp belongs to the fixed body.
    clasp = part(empty, polygon_mask([(673,861),(744,855),(755,885),(774,920),
                                    (754,938),(714,971),(683,948),(656,928),(657,908),(676,891)]))
    lid_outside = part(outer, polygon_mask([(0,0),(1254,0),(1254,800),(1109,812),
                                         (1001,877),(367,922),(200,872),(142,819),(0,790)]))
    cavity_mask = polygon_mask([(187,770),(291,683),(838,645),(1032,698),(1072,766),
                                (983,831),(749,853),(670,864),(366,882),(226,833)])
    contents = {'empty': Image.new('RGBA', SIZE)}
    for level in ('half','full'):
        contents[level] = part(cleaned(Image.open(SOURCE/f'open_{level}.png')), cavity_mask)
    for name, im in {'body':body,'lid_inside':lid_inside,'lid_outside':lid_outside,
                     'hinges':hinges,'clasp':clasp,**{f'contents_{k}':v for k,v in contents.items()}}.items():
        im.save(DEST/'parts'/f'{name}.png')

    # Acceleration, ease-out and a restrained one-degree settling motion.
    angles = [0,4,11,22,36,51,65,78,88,95,98,97,96]
    frames = {}
    for level in LEVELS:
        frames[level] = []
        for index, angle in enumerate(angles):
            im = body.copy()
            im.alpha_composite(contents[level])
            theta = math.radians(angle)
            signed_projection = math.cos(theta) - 1.9*math.sin(theta)
            if signed_projection >= 0:
                lid = hinged(lid_outside, max(.035, signed_projection), -.025*math.sin(theta))
            else:
                denominator = 1.9*math.sin(math.radians(96))-math.cos(math.radians(96))
                lid = hinged(lid_inside, max(.035, -signed_projection/denominator))
            im.alpha_composite(lid)
            if angle >= 36:
                im.alpha_composite(hinges)
            im.alpha_composite(clasp)
            output = world(im)
            name = f'open_{level}_{index:02}.png'
            output.save(DEST/'world'/name)
            frames[level].append(output)
        # The three closed frames are deliberately identical: the opaque lid
        # cannot reveal contents; only open states have fill differences.
        if level == 'empty':
            closed = frames[level][0].copy()
        else:
            frames[level][0] = closed.copy()
            closed.save(DEST/'world'/f'open_{level}_00.png')
        frames[level][-1].save(DEST/'world'/f'opened_{level}.png')
        closed.save(DEST/'world'/f'closed_{level}.png')

    icon_names = {'nw_dustbox':'icon_closed.png',
                  **{f'nw_dustbox_open_{level}':f'icon_open_{level}.png' for level in LEVELS}}
    icons = {}
    for name, src in icon_names.items():
        im = icon(Image.open(SOURCE/src))
        im.save(DEST/'inventory'/f'{name}.png')
        icons[name] = f'inventory/{name}.png'
    Image.open(DEST/'inventory/nw_dustbox_open_half.png').save(DEST/'inventory/nw_dustbox_open.png')
    icons['nw_dustbox_open'] = 'inventory/nw_dustbox_open.png'

    clips = {}
    for level in LEVELS:
        sequence = [f'world/open_{level}_{i:02}.png' for i in range(len(angles))]
        clips[f'closed_{level}'] = {'fps':30, 'frames':[f'world/closed_{level}.png']}
        clips[f'opened_{level}'] = {'fps':30, 'frames':[f'world/opened_{level}.png']}
        clips[f'open_{level}'] = {'fps':30, 'frames':sequence}
        clips[f'close_{level}'] = {'fps':30, 'frames':list(reversed(sequence))}
    manifest = {'version':1,'bank':'nw_dustbox','canvas':list(CANVAS),'anchor':list(ANCHOR),
                'clips':clips,'aliases':{'closed':'closed_empty','open':'open_half',
                                        'opened':'opened_half','close':'close_half'},
                'icons':icons,'shadow':{'mode':'dynamic','size':[1.6,.8],
                   'note':'No baked source shadow. Review ellipse stands in for existing DST DynamicShadow.'},
                'source_canvas':list(SIZE),'source_anchor':list(SOURCE_ANCHOR),
                'runtime_scale_from_source':SCALE,'lid_angles_degrees':angles,
                'fill_semantics':'Empty/half/full are illustrative content-depth states, not finite storage capacity.',
                'integration':'Staged art only; no gameplay thresholds or prefab changes.'}
    (DEST/'clip_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')

    # Actual runtime sprites are used in every review, including fill-state comparisons.
    contact = Image.new('RGB',(1280,350),(190,184,170))
    for i,(label,im) in enumerate([('CLOSED',closed)]+[(level.upper(),frames[level][-1]) for level in LEVELS]):
        contact.paste(preview_sprite(im),(i*320,0))
        ImageDraw.Draw(contact).text((i*320+120,327),label,fill=(35,30,40))
    contact.save(DEST/'review/states.png')
    poses = Image.new('RGB',(7*240,275),(190,184,170))
    for i,index in enumerate((0,2,3,4,6,8,12)):
        poses.paste(preview_sprite(frames['half'][index],240),(i*240,0))
        ImageDraw.Draw(poses).text((i*240+80,250),f'{angles[index]} deg',fill=(35,30,40))
    poses.save(DEST/'review/lid_keyframes.png')
    animation = []
    for level in LEVELS:
        sequence = [closed]*14 + frames[level] + [frames[level][-1]]*22 + list(reversed(frames[level])) + [closed]*7
        for im in sequence:
            bg = preview_sprite(im)
            ImageDraw.Draw(bg).text((12,12),level.upper(),fill=(35,30,40))
            animation.append(bg)
    animation[0].save(DEST/'review/open_close.gif',save_all=True,append_images=animation[1:],duration=33,loop=0)
    iconboard = Image.new('RGB',(640,240),(230,226,213))
    draw = ImageDraw.Draw(iconboard)
    for col,name in enumerate(icon_names):
        im = Image.open(DEST/'inventory'/f'{name}.png')
        for row,bgcolor in enumerate(((230,226,213),(50,46,55))):
            tile = Image.new('RGBA',(160,100),bgcolor+(255,))
            tile.alpha_composite(im,(16,12))
            tile.alpha_composite(im.resize((32,32),Image.Resampling.LANCZOS),(104,28))
            iconboard.paste(tile.convert('RGB'),(col*160,row*100))
        draw.text((col*160+14,215),['CLOSED','EMPTY','HALF','FULL'][col],fill=(35,30,40))
    iconboard.save(DEST/'review/inventory_64_32.png')
    qa = {'alpha_noise_cleanup':'Runtime only: A<=8 -> transparent; A>=250 -> opaque; source untouched.',
          'world_canvas':list(CANVAS),'world_anchor':list(ANCHOR),'runtime_max_width':max(im.getbbox()[2]-im.getbbox()[0] for im in frames['empty']),
          'world_rgba_frames':sum(len(v) for v in frames.values())+6,
          'clips_with_aliases':len(clips)+4,'inventory_icons':len(icons),
          'closed_equal_all_levels':all(np.array_equal(np.array(frames['empty'][0]),np.array(frames[level][0])) for level in LEVELS),
          'fixed_lower_body_rows_135_to_159':all(np.array_equal(np.array(frames['empty'][0])[135:],np.array(im)[135:]) for im in frames['empty']),
          'source_parts':8,'artwork_origin':'All visible surfaces generated with built-in image_gen; masks and transforms only in this build.'}
    (DEST/'qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(qa,indent=2))


if __name__ == '__main__':
    main()
