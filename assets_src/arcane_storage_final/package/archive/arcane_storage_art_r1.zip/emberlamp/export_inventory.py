"""Technically normalize/crop generated UI masters; never redraw their artwork."""
import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image, ImageDraw

BASE = Path(__file__).resolve().parent
SRC = BASE / 'inventory_sources'
OUT = BASE / 'inventory'
REVIEW = BASE / 'inventory_review'
for directory in (OUT, REVIEW):
    directory.mkdir(exist_ok=True)

STATES = ['empty', 'half', 'full', 'half_lit', 'full_lit']
images = {}
boxes = []
for state in STATES:
    image = Image.open(SRC / (state + '.png')).convert('RGBA')
    alpha = image.getchannel('A').point(lambda v: 0 if v <= 8 else v)
    image.putalpha(alpha)
    images[state] = image
    boxes.append(alpha.getbbox())
assert len({im.size for im in images.values()}) == 1
crop = (min(b[0] for b in boxes), min(b[1] for b in boxes),
        max(b[2] for b in boxes), max(b[3] for b in boxes))
scale = min(60 / (crop[2] - crop[0]), 60 / (crop[3] - crop[1]))
scaled_size = (round((crop[2] - crop[0]) * scale), round((crop[3] - crop[1]) * scale))
offset = ((64 - scaled_size[0]) // 2, (64 - scaled_size[1]) // 2)
exports = {}
for state, image in images.items():
    small = image.crop(crop).resize(scaled_size, Image.Resampling.LANCZOS)
    icon = Image.new('RGBA', (64, 64))
    icon.alpha_composite(small, offset)
    path = OUT / ('nw_emberlamp_' + state + '.png')
    icon.save(path)
    icon.resize((32, 32), Image.Resampling.LANCZOS).save(REVIEW / (state + '_32.png'))
    assert icon.getchannel('A').getextrema() == (0, 255)
    assert all(icon.getpixel(xy)[3] == 0 for xy in ((0,0),(63,0),(0,63),(63,63)))
    exports[state] = {'source':str((SRC / (state + '.png')).relative_to(BASE)),
                      'path':str(path.relative_to(BASE)), 'size':[64,64],
                      'source_sha256':hashlib.sha256((SRC / (state + '.png')).read_bytes()).hexdigest(),
                      'alpha_bounds':icon.getchannel('A').getbbox()}
shutil.copyfile(OUT / 'nw_emberlamp_full_lit.png', OUT / 'nw_emberlamp.png')

board = Image.new('RGBA', (1000, 640), '#39363d')
draw = ImageDraw.Draw(board)
draw.text((20,12), 'Arcane Ember Lamp: dedicated inventory icons / actual 64 and 32 px + enlarged check', fill='white')
for i,state in enumerate(STATES):
    x=20+i*196
    draw.text((x,42),state,fill='white')
    icon=Image.open(OUT / ('nw_emberlamp_' + state + '.png')).convert('RGBA')
    # All display panels composite real alpha; RGB in transparent pixels is ignored.
    for row,colour in enumerate(('#b7b8ba','#242128')):
        panel=Image.new('RGBA',(176,250),colour)
        big=icon.resize((128,128),Image.Resampling.NEAREST)
        panel.alpha_composite(big,(24,8))
        panel.alpha_composite(icon,(15,160))
        panel.alpha_composite(icon.resize((32,32),Image.Resampling.LANCZOS),(116,176))
        pd=ImageDraw.Draw(panel)
        label='#242128' if row==0 else '#dddddf'
        pd.text((14,233),'64 px',fill=label)
        pd.text((111,233),'32 px',fill=label)
        board.alpha_composite(panel,(x,65+row*267))
board.convert('RGB').save(REVIEW / 'inventory_contact.png')

manifest={
    'category':'game_inventory_icon', 'tool':'built-in image_gen',
    'runtime_size':[64,64], 'auxiliary_readability_size':[32,32],
    'target_size_basis':'tools/build_supplies.py: existing supply / dustbox tiles use 64 pixels',
    'common_crop':list(crop), 'resized_size':list(scaled_size), 'common_offset':list(offset),
    'source_alpha_noise_threshold':8,
    'processing':'Only transparent-noise clamp, common crop, equal scaling and PNG export. Generated masters unchanged.',
    'approved_identity':'../../arcane_storage_v2/originals/emberlamp_appearance.png',
    'sources':exports,
    'alias':{'inventory/nw_emberlamp.png':'inventory/nw_emberlamp_full_lit.png'},
    'prompt_files':['prompts/ui_01_empty.txt','prompts/ui_02_half.txt','prompts/ui_03_full.txt',
                    'prompts/ui_04_full_powder.txt','prompts/ui_05_half_lit.txt','prompts/ui_06_full_lit.txt'],
    'rejected_source':{'inventory_sources/full_rock_rejected.png':'Powder looked like a single cut gemstone; regenerated as a soft loose mound.'},
    'review':'inventory_review/inventory_contact.png',
    'validation':{'RGBA':True,'transparent_corners':True,'consistent_canvas_scale_and_offset':True,
                  'ground_shadow_in_icons':False}
}
(BASE / 'inventory_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'crop':crop,'scaled_size':scaled_size,'offset':offset,'exports':list(exports)},ensure_ascii=False))
