奥术余烬灯 · 完整美术素材
日期：2026-11-09

沿用用户确认的石底座、黄铜弯臂、挂环、黑色灯帽、紫晶灯盏与青紫火焰。
本轮“打开／关闭”已由用户明确为点燃／熄灭，不是灯盖机械开合。
所有新绘画来自内置 image_gen；原图与实际 Prompt 均保留。运行代码与玩法没有修改。

状态与动画
- 空、半满、满三种未点亮世界图；空档露出深色灯盏内壁，半档薄层粉尘，满档松散粉尘丘。
- 半满、满档分别有点燃、持续燃烧、熄灭动画；空档没有燃烧动画。
- 燃烧：8张不同火舌，30fps，每张停2帧，共约0.533秒。
- 点燃：6张生成过渡画加首尾静态，16帧／30fps，约0.533秒。
- 熄灭：生成火舌逐渐收缩，加首尾静态，14帧／30fps，约0.467秒。
- 原版影灯使用 campfire_fire 的8张 flames_wide 火焰，参考其造型变化和节奏；本包火焰为新绘制的已确认青紫配色。
- 灯体只用一个固定母版，粉尘和火焰分别拆层；用像素比较检查动画过程中支架、底座不跳动。

目录与规格
- originals：生成原图，包括清楚标记为 superseded 的过程稿；最终选用情况见 generation_manifest.json。
- prompts：实际提交的世界与UI Prompt；序号缺口不代表缺少成品。
- layers：透明灯体、粉尘、地影及逐帧火焰；均可独立调整。
- world：256×320透明运行帧，地面锚点(128,302)，本体可见高度约285像素。
- inventory：64×64专用简化图标，三种未点亮、两种点亮及默认别名；检查图另含32像素预览。
- previews/states.png：三档存量与两档点亮预览。
- previews/ignite_burn_extinguish_half.gif、ignite_burn_extinguish_full.gif：完整启灭与燃烧预览。
- clip_manifest.json：全部动画、帧率、图标与影子配置。
- generation_manifest.json、inventory_manifest.json：来源与提示词溯源。

阴影与分层
地影使用项目现有原版风格短线阴影 researchlab2_machine_shadow.png，另存 layers/ground_shadow.png。
地影在世界动画导出时合成，接入这个银行时不要再叠加 DynamicShadow；物品栏不含地影。
灯光由后续游戏组件控制，PNG不烘焙大面积光晕。所有镂空及背景保留真透明Alpha。
运行导出仅清理 <=8/255 的近透明杂点，并把 >=247/255 的内部覆盖规范为不透明；原图保持不变。

复建
.venv/Scripts/python.exe tools/build_emberlamp_art.py
.venv/Scripts/python.exe assets_src/arcane_storage_final/emberlamp/export_inventory.py
.venv/Scripts/python.exe tools/package_arcane_storage_art.py

这是美术交付；三档与数量、燃料时间的映射尚未接入，没有自动引入新的容量或消耗规则。
