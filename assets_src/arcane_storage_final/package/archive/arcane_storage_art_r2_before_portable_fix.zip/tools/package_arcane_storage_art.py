"""Compile approved storage art into a standalone review package.

This script never writes to mod/ or an installed game. Input PNGs are already
authored at runtime resolution; packaging preserves their size and RGBA pixels.
See assets_src/arcane_storage_final/clip_manifest_schema.json for the contract.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import subprocess
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from PIL import Image, ImageDraw

from animation_atlas import validate_animation_archive, validate_ktex
from native_animation import NativeAnimation, read_animation, read_build, texture

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "assets_src/arcane_storage_final"
TOOLS = Path("E:/SteamLibrary/steamapps/common/Don't Starve Mod Tools/mod_tools")
NAME = re.compile(r"^[a-z][a-z0-9_]*$")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def named(value, label):
    require(isinstance(value, str) and NAME.fullmatch(value), f"{label}: invalid name {value!r}")
    return value


def source_path(root, relative):
    require(isinstance(relative, str), "asset path must be a string")
    path = (root / relative).resolve()
    require(path.is_relative_to(root.resolve()), f"asset escapes its source directory: {relative}")
    require(path.suffix.lower() == ".png" and path.is_file(), f"missing PNG: {path}")
    return path


def inspect_png(path, canvas):
    with Image.open(path) as opened:
        require(opened.mode == "RGBA", f"{path}: expected authored RGBA, got {opened.mode}")
        im = opened.copy()
    require(im.size == tuple(canvas), f"{path}: {im.size} differs from declared canvas {canvas}")
    alpha = im.getchannel("A")
    low, high = alpha.getextrema()
    require(low == 0 and high > 0, f"{path}: expected nonempty artwork and transparent background")
    visible = alpha.point(lambda value: 255 if value > 8 else 0).getbbox()
    require(visible is not None, f"{path}: artwork is practically invisible")
    require(visible[0] > 0 and visible[1] > 0 and visible[2] < im.width and visible[3] < im.height,
            f"{path}: visible artwork touches canvas edge: {visible}")
    require(all(alpha.getpixel(p) == 0 for p in ((0, 0), (im.width-1, 0),
                                               (0, im.height-1), (im.width-1, im.height-1))),
            f"{path}: corners must be fully transparent")
    return im, {"size": list(im.size), "alpha_extrema": [low, high], "visible_bbox": list(visible),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def load_manifest(path):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    require(data.get("version") == 1, f"{path}: expected manifest version 1")
    bank = named(data.get("bank"), "bank")
    canvas = data.get("canvas")
    require(isinstance(canvas, list) and len(canvas) == 2 and
            all(isinstance(v, int) and v > 0 for v in canvas), f"{bank}: invalid canvas")
    anchor = data.get("anchor")
    require(isinstance(anchor, list) and len(anchor) == 2 and
            all(isinstance(v, (int, float)) and math.isfinite(v) and 0 <= v <= canvas[i]
                for i, v in enumerate(anchor)), f"{bank}: invalid pixel anchor")
    clips = data.get("clips")
    require(isinstance(clips, dict) and clips, f"{bank}: no animation clips")
    clips = dict(clips)
    aliases = data.get("aliases", {})
    require(isinstance(aliases, dict), f"{bank}: aliases must be a mapping")
    for name, target in aliases.items():
        named(name, "animation alias")
        require(name not in clips and target in clips, f"{bank}: invalid alias {name} -> {target}")
        clips[name] = clips[target]
    pictures, reports = {}, {}
    for name, clip in clips.items():
        named(name, "animation")
        fps = clip.get("fps")
        require(isinstance(fps, (int, float)) and math.isfinite(fps) and 0 < fps <= 120,
                f"{bank}/{name}: invalid fps")
        require(isinstance(clip.get("frames"), list) and clip["frames"], f"{bank}/{name}: no frames")
        for relative in clip["frames"]:
            if relative not in pictures:
                pictures[relative], reports[relative] = inspect_png(source_path(path.parent, relative), canvas)
    icons, icon_reports = {}, {}
    for name, relative in data.get("icons", {}).items():
        named(name, "inventory element")
        icons[name], icon_reports[name] = inspect_png(source_path(path.parent, relative), (64, 64))
    require(icons, f"{bank}: no inventory icons")
    return data, clips, pictures, icons, reports, icon_reports


def write_xml(path, element):
    ET.indent(element)
    ET.ElementTree(element).write(path, encoding="utf-8", xml_declaration=True)


def compile_bank(manifest, package, tools):
    data, clips, pictures, icons, png_report, icon_report = load_manifest(manifest)
    bank = data["bank"]
    width, height = data["canvas"]
    # Build coordinates describe the image centre relative to its ground anchor.
    pivot = (width / 2 - data["anchor"][0], height / 2 - data["anchor"][1])
    stage = package / "source" / bank
    stage.mkdir(parents=True, exist_ok=True)
    build = ET.Element("Build", name=bank)
    animations = ET.Element("Anims")
    digest_symbols, path_symbols = {}, {}
    for path, picture in pictures.items():
        digest = hashlib.sha256(picture.tobytes()).hexdigest()
        if digest not in digest_symbols:
            symbol = f"pose_{len(digest_symbols):03}"
            digest_symbols[digest] = symbol
            picture.save(stage / (symbol + ".png"))
            node = ET.SubElement(build, "Symbol", name=symbol)
            ET.SubElement(node, "Frame", framenum="0", duration="1", image=symbol,
                          x=str(pivot[0]), y=str(pivot[1]), w=str(width), h=str(height))
        path_symbols[path] = digest_symbols[digest]
    for name, clip in clips.items():
        node = ET.SubElement(animations, "anim", name=name, root=bank, framerate=str(clip["fps"]))
        for path in clip["frames"]:
            pose = ET.SubElement(node, "frame", x=str(pivot[0]), y=str(pivot[1]),
                                 w=str(width), h=str(height))
            ET.SubElement(pose, "element", name=path_symbols[path], frame="0", layername="body",
                          z_index="0", m_a="1", m_b="0", m_c="0", m_d="1", m_tx="0", m_ty="0")
    write_xml(stage / "build.xml", build)
    write_xml(stage / "animation.xml", animations)
    source_zip = package / "source" / (bank + ".zip")
    with zipfile.ZipFile(source_zip, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in list(digest_symbols.values()):
            archive.write(stage / (name + ".png"), name + ".png")
        for name in ("build.xml", "animation.xml"):
            archive.write(stage / name, name)
    result = subprocess.run([
        str(tools / "buildtools/windows/Python27/python.exe"),
        str(tools / "tools/scripts/buildanimation.py"), str(source_zip),
        "--outputdir", str(package), "--scale", "1", "--force"],
        cwd=tools, capture_output=True, timeout=180)
    log = package / "validation" / (bank + "_compiler.log")
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_bytes(result.stdout + result.stderr)
    require(result.returncode == 0, f"{bank}: compiler failed; see {log}")
    target = package / "anim" / (bank + ".zip")
    compiled = validate_animation_archive(target)
    with zipfile.ZipFile(target) as archive:
        actual_clips = read_animation(archive.read("anim.bin"))
        actual = {clip["name"]: clip for clip in actual_clips}
        actual_build = read_build(archive.read("build.bin"))
        renderer = NativeAnimation.__new__(NativeAnimation)
        renderer.clips, renderer.build, renderer.cache = actual_clips, actual_build, {}
        renderer.atlases = [texture(archive.read(name)) for name in actual_build["atlases"]]
    require(actual_build["name"] == bank, f"{bank}: compiled build changed name")
    require(set(actual) == set(clips), f"{bank}: compiled animation names differ")
    for name, clip in clips.items():
        require(len(actual[name]["frames"]) == len(clip["frames"]), f"{bank}/{name}: frame count mismatch")
        require(abs(actual[name]["fps"] - clip["fps"]) < .001, f"{bank}/{name}: frame rate mismatch")
        require(all(len(frame["elements"]) == 1 for frame in actual[name]["frames"]),
                f"{bank}/{name}: compiled frame missing artwork")
    # Check the coordinate bounds stored by the compiler as well as source JSON.
    for frames in actual_build["frames"].values():
        for row in frames:
            require(abs(row[2] - pivot[0]) < .001 and abs(row[3] - pivot[1]) < .001,
                    f"{bank}: compiled anchor differs from authored anchor")
    # Reconstruct representative frames from the actual compiled bank so the
    # review also exposes atlas packing, compression and coordinate mistakes.
    review_names = list(data["clips"])
    cell_w, cell_h = max(240, width + 24), max(220, height + 50)
    review = Image.new("RGBA", (cell_w * 3, math.ceil(len(review_names) / 3) * cell_h), "#77766f")
    drawing = ImageDraw.Draw(review)
    for i, name in enumerate(review_names):
        x, y = i % 3 * cell_w, i // 3 * cell_h
        drawing.text((x+10, y+10), name, fill="white")
        index = len(clips[name]["frames"]) // 2
        sprite, (left, top) = renderer.render_frame(name, index)
        px = x + (cell_w-width)//2 + round(data["anchor"][0]) + left
        py = y + 35 + round(data["anchor"][1]) + top
        review.alpha_composite(sprite, (px, py))
    review.convert("RGB").save(package / "validation" / (bank + "_compiled_review.png"))
    report = {"bank": bank, "manifest": str(manifest.relative_to(SOURCE)),
              "canvas": data["canvas"], "ground_anchor_pixels": data["anchor"],
              "build_pivot": list(pivot), "shadow": data.get("shadow"),
              "compiled_archive": compiled, "unique_images": len(digest_symbols),
              "visible_bottom_range_pixels": [min(row["visible_bbox"][3] for row in png_report.values()),
                                                max(row["visible_bbox"][3] for row in png_report.values())],
              "clips": {name: {"fps": clip["fps"], "frames": len(clip["frames"]),
                                "duration_seconds": len(clip["frames"]) / clip["fps"]}
                        for name, clip in clips.items()},
              "source_png_checks": png_report, "inventory_png_checks": icon_report}
    return report, icons


def inventory_atlas(icons, package, tools):
    count = len(icons)
    columns = min(8, 2 ** math.ceil(math.log2(max(1, count))))
    rows = 2 ** math.ceil(math.log2(math.ceil(count / columns)))
    sheet = Image.new("RGBA", (columns * 64, rows * 64))
    atlas = ET.Element("Atlas")
    ET.SubElement(atlas, "Texture", filename="nw_arcane_storage.tex")
    entries = ET.SubElement(atlas, "Elements")
    for i, (name, icon) in enumerate(icons.items()):
        x, y = i % columns * 64, i // columns * 64
        sheet.alpha_composite(icon, (x, y))
        ET.SubElement(entries, "Element", name=name + ".tex", u1=str(x / sheet.width),
                      u2=str((x+64) / sheet.width), v1=str(1 - (y+64) / sheet.height),
                      v2=str(1 - y / sheet.height))
    target = package / "images/inventoryimages"
    target.mkdir(parents=True, exist_ok=True)
    png = target / "nw_arcane_storage.png"
    sheet.save(png)
    write_xml(target / "nw_arcane_storage.xml", atlas)
    result = subprocess.run([str(tools / "tools/bin/TextureConverter.exe"), "--swizzle",
                             "--format", "bc3", "--platform", "opengl", "--premultiply",
                             "-i", str(png), "-o", str(target / "nw_arcane_storage.tex")],
                            capture_output=True, timeout=90)
    (package / "validation/inventory_compiler.log").write_bytes(result.stdout + result.stderr)
    require(result.returncode == 0, "inventory texture compiler failed")
    validate_ktex((target / "nw_arcane_storage.tex").read_bytes(), "nw_arcane_storage.tex")
    # Show actual-size 64 and 32 px output against both light and dark UI fields.
    review = Image.new("RGB", (600, max(1, count) * 96 + 35), "#797979")
    draw = ImageDraw.Draw(review)
    draw.text((12, 10), "64 px / 32 px: light and dark backgrounds", fill="white")
    for i, (name, icon) in enumerate(icons.items()):
        y = 35 + i * 96
        draw.text((8, y+32), name, fill="white")
        for x, colour in ((260, "#d3c9b7"), (425, "#26262c")):
            draw.rectangle((x, y, x+155, y+86), fill=colour)
            review.paste(icon, (x+6, y+10), icon)
            small = icon.resize((32, 32), Image.Resampling.LANCZOS)
            review.paste(small, (x+104, y+26), small)
    review.save(package / "validation/inventory_64_32_review.png")
    return {"atlas": "images/inventoryimages/nw_arcane_storage.xml", "element_size": [64, 64],
            "atlas_size": list(sheet.size), "elements": list(icons), "format": "BC3 premultiplied RGBA"}


def write_viewer(package, names):
    """A local-file review page: inline metadata avoids browser fetch/CORS."""
    assets = []
    for name in names:
        data = json.loads((SOURCE / name / "clip_manifest.json").read_text(encoding="utf-8-sig"))
        data["directory"] = "../" + name + "/"
        data["label"] = {"dustbox": "粉尘收纳盒", "emberlamp": "奥术余烬灯"}[name]
        assets.append(data)
    payload = json.dumps(assets, ensure_ascii=False).replace("</", "<\\/")
    html = r'''<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>收纳盒与余烬灯 · 动画检查</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#1f2023;color:#efebe4;font:15px/1.6 system-ui,"Microsoft YaHei",sans-serif}
main{max-width:1160px;margin:0 auto;padding:32px 24px}h1{font-size:27px;margin:0 0 8px}p{color:#c1bcb3;margin:0 0 22px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(350px,1fr));gap:24px}.card{width:100%;max-width:560px;background:#2c2c31;border:1px solid #49464d;border-radius:14px;overflow:hidden}
h2{font-size:19px;padding:16px 20px;margin:0}canvas{display:block;width:100%;height:auto;background:#77766f}.controls{padding:16px 20px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
select,button{font:inherit;color:#f4ecdf;background:#3c3740;border:1px solid #746775;border-radius:7px;padding:7px 10px}button{cursor:pointer}select{max-width:100%}
label{white-space:nowrap}.meta{padding:0 20px 16px;color:#bab3bf;font-size:13px}.error{color:#ffb8a4}.icons{padding:0 20px 18px;display:flex;gap:12px;flex-wrap:wrap}.icons img{width:64px;height:64px;background:#66615b;border-radius:4px}
</style><main><h1>收纳盒与余烬灯 · 动画检查</h1>
<p>分别放大查看空、半满、满三档及各段动画。地面版保留贴地阴影，物品栏图标使用透明背景。</p>
<div class="grid" id="grid"></div></main><script>
const assets=__ASSETS__;
const labels={empty:'空',half:'半满',full:'满',closed:'合盖静止',opened:'开盖静止',open:'开盖',close:'合盖',off:'未点燃',on:'点燃静止',ignite:'点燃',extinguish:'熄灭',burn:'燃烧循环',burning:'燃烧循环',loop:'循环',idle:'静止',turn:'',pre:'开始',post:'结束'};
const title=name=>name.split('_').map(part=>labels[part]??part).filter(Boolean).join(' · ');
const imageCache=new Map();
function picture(path){if(!imageCache.has(path)){const im=new Image();const promise=new Promise((resolve,reject)=>{im.onload=()=>resolve(im);im.onerror=()=>reject(new Error('无法读取 '+path));});im.src=path;imageCache.set(path,promise);}return imageCache.get(path);}
for(const data of assets){
 const card=document.createElement('section');card.className='card';
 card.innerHTML='<h2></h2><canvas width="520" height="390"></canvas><div class="controls"><select aria-label="动画"></select><button>暂停</button><button>重播</button><label><input type="checkbox" checked>循环</label><select aria-label="检查背景"><option value="#77766f">中性底</option><option value="#d3c9b7">浅底</option><option value="#26262c">深底</option></select></div><div class="meta"></div><div class="icons"></div>';
 document.getElementById('grid').appendChild(card);card.querySelector('h2').textContent=data.label;
 const canvas=card.querySelector('canvas'),ctx=canvas.getContext('2d'),[clips,bg]=card.querySelectorAll('select'),[pause,restart]=card.querySelectorAll('button'),loop=card.querySelector('input'),meta=card.querySelector('.meta');
 for(const name of Object.keys(data.clips)){const o=document.createElement('option');o.value=name;o.textContent=title(name);clips.appendChild(o);}
 for(const preferred of ['opened_half','burn_half','on_half','idle_half','off_half']){if(data.clips[preferred]){clips.value=preferred;break;}}
 let frames=[],started=performance.now(),paused=false,pauseAt=0,loadId=0,error='';
 async function load(){const id=++loadId;frames=[];error='';try{const next=await Promise.all(data.clips[clips.value].frames.map(path=>picture(data.directory+path)));if(id===loadId){frames=next;started=performance.now();pauseAt=0;meta.className='meta';}}catch(e){error=e.message;meta.textContent=error;meta.className='meta error';}}
 clips.onchange=load;pause.onclick=()=>{paused=!paused;if(paused){pauseAt=performance.now()-started;pause.textContent='播放';}else{started=performance.now()-pauseAt;pause.textContent='暂停';}};
 restart.onclick=()=>{started=performance.now();pauseAt=0;};
 for(const [name,path] of Object.entries(data.icons)){const im=document.createElement('img');im.src=data.directory+path;im.alt=name;im.title=name;card.querySelector('.icons').appendChild(im);}
 function tick(now){const [w,h]=data.canvas;const scale=Math.min(1.75,480/w,340/h);const ox=(canvas.width-w*scale)/2,oy=canvas.height-24-data.anchor[1]*scale;
 ctx.fillStyle=bg.value;ctx.fillRect(0,0,canvas.width,canvas.height);
 if(data.shadow?.mode==='dynamic'){ctx.fillStyle='rgba(19,17,23,.30)';ctx.beginPath();ctx.ellipse(ox+data.anchor[0]*scale,oy+data.anchor[1]*scale,w*.29*scale,Math.max(7,w*.048*scale),0,0,Math.PI*2);ctx.fill();}
 if(frames.length){const clip=data.clips[clips.value],time=Math.max(0,paused?pauseAt:now-started);let index=Math.floor(time/1000*clip.fps);index=loop.checked?index%frames.length:Math.min(index,frames.length-1);ctx.drawImage(frames[index],ox,oy,w*scale,h*scale);meta.textContent=`${index+1} / ${frames.length} 帧 · ${clip.fps} fps`;}
 else if(!error){meta.textContent='载入透明帧…';}requestAnimationFrame(tick);}
 load();requestAnimationFrame(tick);
}
</script></html>'''
    (package / "review.html").write_text(html.replace("__ASSETS__", payload), encoding="utf8")


def write_bundle(package, names, reports, inventory):
    lines = [
        "粉尘收纳盒与奥术余烬灯：美术交付包", "",
        "本包包含透明源图、分层素材、状态帧、动画预览、物品栏图标及官方工具编译的动画和纹理。",
        "这是独立的美术包；未修改 mod 脚本、未安装到游戏，未执行实机玩法验收。",
        "空／半满／满是美术状态。无限容器的数量到状态映射由后续接入逻辑定义，满态不代表容量上限。",
        "地面阴影依据各 clip_manifest.json 的 shadow 配置接入；已合成地影的世界帧不再叠加 DynamicShadow。物品栏图标不含地影。", "",
        "目录：", "  dustbox/、emberlamp/：生成源图、Prompt、分层、世界帧、图标及清单。",
        "  runtime/anim/：可供 AnimState 使用的原生动画包。",
        "  runtime/images/inventoryimages/：64 像素图标图集；使用 nw_arcane_storage.xml 的元素名称。",
        "  animation_source/：官方编译器输入 ZIP，内含 build.xml、animation.xml 和逐帧 PNG。",
        "  tools/：本项目使用的分层／动画／打包脚本及读取校验工具；保留本项目目录约定。",
        "  validation/：编译日志、资源检查报告、64／32 像素浅深底预览。",
        "  review/review.html：解压后直接打开即可逐项查看动画；项目内对应 package/review.html。", "",
        "动画：",
    ]
    for report in reports:
        lines.append(f"  bank/build: {report['bank']}; canvas: {report['canvas']}; anchor: {report['ground_anchor_pixels']}")
        for name, clip in report["clips"].items():
            lines.append(f"    {name}: {clip['frames']} frames @ {clip['fps']} fps")
    lines.extend(["", "图标元素：", *["  " + name + ".tex" for name in inventory["elements"]], "",
                  "复建（在本项目根目录）：",
                  "  .venv/Scripts/python.exe tools/package_arcane_storage_art.py", "",
                  "各图像的真正透明 Alpha 在 PNG 源图中保留。编译结果已检查 ANIM/BILD、KTEX、图集页数、动画名称、帧数、帧率及锚点。"])
    readme = package / "README.txt"
    readme.write_text("\n".join(lines) + "\n", encoding="utf8")
    bundle = package / "arcane_storage_art_bundle.zip"
    with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(readme, "README.txt")
        archive.write(package / "review.html", "review/review.html")
        archive.write(SOURCE / "clip_manifest_schema.json", "clip_manifest_schema.json")
        for report in reports:
            source_zip = package / "source" / (report["bank"] + ".zip")
            archive.write(source_zip, "animation_source/" + source_zip.name)
        for script in ("build_dustbox_jewellery_art.py", "build_emberlamp_art.py",
                       "package_arcane_storage_art.py", "animation_atlas.py", "native_animation.py"):
            archive.write(ROOT / "tools" / script, "tools/" + script)
        for name in names:
            for path in sorted((SOURCE / name).rglob("*")):
                if path.is_file() and "_rejected" not in path.stem:
                    archive.write(path, path.relative_to(SOURCE).as_posix())
        for folder in ("anim", "images", "validation"):
            for path in sorted((package / folder).rglob("*")):
                if path.is_file():
                    prefix = "" if folder == "validation" else "runtime/"
                    archive.write(path, prefix + path.relative_to(package).as_posix())
    return bundle


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--asset", choices=("dustbox", "emberlamp"), action="append",
                        help="Build one asset while the other is still being authored")
    parser.add_argument("--validate-only", action="store_true", help="Check source PNGs without compiling")
    parser.add_argument("--tools", type=Path, default=TOOLS)
    args = parser.parse_args()
    names = args.asset or ["dustbox", "emberlamp"]
    package = SOURCE / "package"
    reports, icons = [], {}
    for name in names:
        manifest = SOURCE / name / "clip_manifest.json"
        require(manifest.is_file(), f"missing manifest: {manifest}")
        if args.validate_only:
            data, clips, pictures, asset_icons, _, _ = load_manifest(manifest)
            print(f"Validated {name}: {len(clips)} clips, {len(pictures)} PNG frames, {len(asset_icons)} icons")
            continue
        report, asset_icons = compile_bank(manifest, package, args.tools)
        require(not set(icons).intersection(asset_icons), "duplicate inventory element names")
        icons.update(asset_icons)
        reports.append(report)
        print(f"Compiled {name}: {len(report['clips'])} clips; {report['compiled_archive']['atlas_count']} atlas page(s)")
    if args.validate_only:
        return
    inventory = inventory_atlas(icons, package, args.tools)
    result = {"status": "compiled_and_structurally_validated", "installed": False,
              "runtime_gameplay_validation": "not performed; art-only staged package",
              "assets": reports, "inventory": inventory}
    (package / "validation/report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf8")
    write_viewer(package, names)
    bundle = write_bundle(package, names, reports, inventory)
    print(f"Standalone package: {package}")
    print(f"All art bundle: {bundle}")


if __name__ == "__main__":
    main()
